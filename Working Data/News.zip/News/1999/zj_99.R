# This file is for 1999 Zhejiang news analsis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1999 data
n99 <- read_csv("Raw Data/People's Daily News Title/PD_1999.csv")


# Extract relevant news ----
sum(str_detect(n99$news_title, "浙江"))
zj <- c("浙江","浙", "杭州", "宁波", "温州", 
        "嘉兴", "湖州","绍兴", "金华","衢州", 
        "舟山","台州", "丽水")
n99_33 <- n99[str_detect(n99$news_title, paste(zj, collapse="|")),]
n99_33$prov_cde <- 33
dim(n99_33)

write_excel_csv(n99_33, file= "Working Data/V2.2 Individual level/News/1999/n99_33.csv")
