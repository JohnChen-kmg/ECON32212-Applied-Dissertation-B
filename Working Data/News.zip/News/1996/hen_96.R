# This file is for 1996 Henan news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1996 data
n96 <- read_csv("Raw Data/People's Daily News Title/PD_1996.csv")


# Extract relevant news ----
sum(str_detect(n96$news_title, "河南"))

hen <- c("河南", "豫", "郑州", "开封", "洛阳", 
        "平顶山", "安阳","鹤壁", "新乡","焦作", "濮阳", "许昌",
        "漯河", "三门峡","南阳", "商丘","信阳", "周口", "驻马店",
        "济源")

n96_41 <- n96[str_detect(n96$news_title, paste(hen, collapse="|")),]
n96_41$prov_cde <- 41
dim(n96_41)

write_excel_csv(n96_41, file= "Working Data/V2.2 Individual level/News/1996/n96_41.csv")
