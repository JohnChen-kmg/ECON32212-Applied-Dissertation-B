# This file is for 1999 Hebei news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1999 data
n99 <- read_csv("Raw Data/People's Daily News Title/PD_1999.csv")


# Extract relevant news ----
sum(str_detect(n99$news_title, "河北"))

hb <- c("河北", "石家庄", "唐山", "秦皇岛", "邯郸", 
        "邢台", "保定","张家口", "承德","沧州", "廊坊", "衡水")
n99_13 <- n99[str_detect(n99$news_title, paste(hb, collapse="|")),]
n99_13$prov_cde <- 13
dim(n99_13)

write_excel_csv(n99_13, file= "Working Data/V2.2 Individual level/News/1999/n99_13.csv")

