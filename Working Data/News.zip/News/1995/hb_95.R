# This file is for 1995 Hebei news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1995 data
n95 <- read_csv("Raw Data/People's Daily News Title/PD_1995.csv")


# Extract relevant news ----
sum(str_detect(n95$news_title, "河北"))

hb <- c("河北", "石家庄", "唐山", "秦皇岛", "邯郸", 
        "邢台", "保定","张家口", "承德","沧州", "廊坊", "衡水")
n95_13 <- n95[str_detect(n95$news_title, paste(hb, collapse="|")),]
n95_13$prov_cde <- 13
dim(n95_13)

write_excel_csv(n95_13, file= "Working Data/V2.2 Individual level/News/1995/n95_13.csv")

