# This file is for 1997 Fujian news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1997 data
n97 <- read_csv("Raw Data/People's Daily News Title/PD_1997.csv")


# Extract relevant news ----
sum(str_detect(n97$news_title, "福建"))

fj <- c("福建","闽", "厦门", "莆田", "三明", "泉州", 
        "漳州", "南平","龙岩", "宁德")

n97_35 <- n97[str_detect(n97$news_title, paste(fj, collapse="|")),]
n97_35$prov_cde <- 35
dim(n97_35)

write_excel_csv(n97_35, file= "Working Data/V2.2 Individual level/News/1997/n97_35.csv")
