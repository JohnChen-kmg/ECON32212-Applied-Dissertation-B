# This file is for 2000 Beijing news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 2000 data
n00 <- read_csv("Raw Data/People's Daily News Title/PD_2000.csv")


# Extract relevant news ----
sum(str_detect(n00$news_title, "东城"))

bj <- c("北京")

n00_11 <- n00[str_detect(n00$news_title, paste(bj, collapse="|")),]
n00_11$prov_cde <- 11
dim(n00_11)

write_excel_csv(n00_11, file= "Working Data/V2.2 Individual level/News/2000/n00_11.csv")

