# This file is for 1995 Guangdong news analsis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1995 data
n95 <- read_csv("Raw Data/People's Daily News Title/PD_1995.csv")


# Extract relevant news ----
sum(str_detect(n95$news_title, "广东"))
gd <- c("广东", "粤", "广州", "深圳", "佛山", "湛江", 
        "韶关", "珠海","汕头", "佛山","江门", "茂名","肇庆", "惠州",
        "梅州", "汕尾", "河源", "阳江", "清远", "东莞", "中山", "潮州",
        "揭阳", "云浮")

n95_44 <- n95[str_detect(n95$news_title, paste(gd, collapse="|")),]
n95_44$prov_cde <- 44
dim(n95_44)

write_excel_csv(n95_44, file= "Working Data/V2.2 Individual level/News/1995/n95_44.csv")
           
