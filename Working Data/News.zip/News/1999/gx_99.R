# This file is for 1999 Guangxi news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1999 data
n99 <- read_csv("Raw Data/People's Daily News Title/PD_1999.csv")


# Extract relevant news ----
sum(str_detect(n99$news_title, "广西"))

gx <- c("广西", "南宁", "柳州", "桂林", "梧州", 
        "北海", "防城港","钦州", "贵港","玉林", "百色",
        "贺州", "河池", "崇左")

n99_45 <- n99[str_detect(n99$news_title, paste(gx, collapse="|")),]
n99_45$prov_cde <- 45
dim(n99_45)

write_excel_csv(n99_45, file= "Working Data/V2.2 Individual level/News/1999/n99_45.csv")
