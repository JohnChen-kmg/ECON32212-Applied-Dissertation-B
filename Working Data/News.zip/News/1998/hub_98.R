# This file is for 1998 Hubei news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1998 data
n98 <- read_csv("Raw Data/People's Daily News Title/PD_1998.csv")


# Extract relevant news ----
sum(str_detect(n98$news_title, "湖北"))

hub <- c("湖北", "鄂", "黄石", "十堰", "宜昌", 
        "襄阳", "鄂州","荆门", "孝感","荆州", "黄冈",
        "咸宁", "随州", "恩施", "仙桃","潜江", "天门市",
        "神农架")

n98_42 <- n98[str_detect(n98$news_title, paste(hub, collapse="|")),]
n98_42$prov_cde <- 42
dim(n98_42)

write_excel_csv(n98_42, file= "Working Data/V2.2 Individual level/News/1998/n98_42.csv")
