# This file is for 1999 Shandong news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1999 data
n99 <- read_csv("Raw Data/People's Daily News Title/PD_1999.csv")


# Extract relevant news ----
sum(str_detect(n99$news_title, "山东"))

sd <- c("山东","济南", "青岛", "淄博", "枣庄", "东营", 
        "烟台", "潍坊","济宁", "泰安","威海", "日照",
        "临沂", "德州","聊城", "滨州","菏泽")

n99_37 <- n99[str_detect(n99$news_title, paste(sd, collapse="|")),]
n99_37$prov_cde <- 37
dim(n99_37)

write_excel_csv(n99_37, file= "Working Data/V2.2 Individual level/News/1999/n99_37.csv")