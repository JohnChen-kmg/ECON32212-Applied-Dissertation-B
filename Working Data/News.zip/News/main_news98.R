# The output is  post classified 1998 news data for 15 provinces

# Prep work
# rm(list=ls())

# Step 1 Load the files
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Working Data/V2.2 Individual level/News/1998")
myFiles <- list.files(pattern="_98.R") 
myFiles <- myFiles[!myFiles %in% "classification_98.R"]
for(i in 1:length(myFiles)){
        setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Working Data/V2.2 Individual level/News/1998")
        source(myFiles[i])
}
rm(list=ls()) 

# Step 2 Classification
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Working Data/V2.2 Individual level/News/1998")
source("classification_98.R")
