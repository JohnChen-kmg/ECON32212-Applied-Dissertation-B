# This file is for 1999 Jiangsu news analsis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1999 data
n99 <- read_csv("Raw Data/People's Daily News Title/PD_1999.csv")


# Extract relevant news ----
sum(str_detect(n99$news_title, "江苏"))
js <- c("江苏", "南京", "无锡", "徐州", "常州", 
        "苏州", "南通","连云港", "淮安","盐城", "扬州","镇江", "泰州",
        "宿迁")

n99_32 <- n99[str_detect(n99$news_title, paste(js, collapse="|")),]
n99_32$prov_cde <- 32
dim(n99_32)

write_excel_csv(n99_32, file= "Working Data/V2.2 Individual level/News/1999/n99_32.csv")
