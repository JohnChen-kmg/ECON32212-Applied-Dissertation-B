# This file is for 1999 Henan news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1999 data
n99 <- read_csv("Raw Data/People's Daily News Title/PD_1999.csv")


# Extract relevant news ----
sum(str_detect(n99$news_title, "河南"))

hen <- c("河南", "豫", "郑州", "开封", "洛阳", 
        "平顶山", "安阳","鹤壁", "新乡","焦作", "濮阳", "许昌",
        "漯河", "三门峡","南阳", "商丘","信阳", "周口", "驻马店",
        "济源")

n99_41 <- n99[str_detect(n99$news_title, paste(hen, collapse="|")),]
n99_41$prov_cde <- 41
dim(n99_41)

write_excel_csv(n99_41, file= "Working Data/V2.2 Individual level/News/1999/n99_41.csv")
