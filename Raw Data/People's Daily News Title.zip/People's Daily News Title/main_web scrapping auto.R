# Run web scrapping files

# Prep work
# rm(list=ls())

# 1985
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Raw Data/People's Daily News Title")
source("PD_1985 web scrapping.R")
rm(list=ls())

# 1986
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Raw Data/People's Daily News Title")
source("PD_1986 web scrapping.R")
rm(list=ls())

# 1987
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Raw Data/People's Daily News Title")
source("PD_1987 web scrapping.R")
rm(list=ls())

# 1988
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Raw Data/People's Daily News Title")
source("PD_1988 web scrapping.R")
rm(list=ls())

# 1989
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Raw Data/People's Daily News Title")
source("PD_1989 web scrapping.R")
rm(list=ls())

# 1990
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Raw Data/People's Daily News Title")
source("PD_1990 web scrapping.R")
rm(list=ls())

# 1991
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Raw Data/People's Daily News Title")
source("PD_1991 web scrapping.R")
rm(list=ls())

# 1992
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Raw Data/People's Daily News Title")
source("PD_1992 web scrapping.R")
rm(list=ls())

# 1993
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Raw Data/People's Daily News Title")
source("PD_1993 web scrapping.R")
rm(list=ls())

# 1994
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Raw Data/People's Daily News Title")
source("PD_1994 web scrapping.R")
rm(list=ls())