# This file is for 2000 Jiangxi news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 2000 data
n00 <- read_csv("Raw Data/People's Daily News Title/PD_2000.csv")


# Extract relevant news ----
sum(str_detect(n00$news_title, "江西"))

jx <- c("江西","赣", "南昌", "景德镇", "萍乡", "九江", 
        "新余", "鹰潭","赣州", "吉安","宜春", "上饶")

n00_36 <- n00[str_detect(n00$news_title, paste(jx, collapse="|")),]
n00_36$prov_cde <- 36
dim(n00_36)

write_excel_csv(n00_36, file= "Working Data/V2.2 Individual level/News/2000/n00_36.csv")