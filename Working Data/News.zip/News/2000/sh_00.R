# This file is for 2000 Shanghai news analsis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 2000 data
n00 <- read_csv("Raw Data/People's Daily News Title/PD_2000.csv")


# Extract relevant news ----
sum(str_detect(n00$news_title, "上海"))
sh <- c("上海", "沪" , "黄浦", "静安", 
        "普陀", "普陀","长宁", "卢湾","徐汇", "闸北","虹口", "杨浦",
        "宝山", "嘉定", "南汇", "奉贤", "松江", "青浦", "崇明")

n00_31 <- n00[str_detect(n00$news_title, paste(sh, collapse="|")),]
n00_31$prov_cde <- 31
dim(n00_31)

write_excel_csv(n00_31, file="Working Data/V2.2 Individual level/News/2000/n00_31.csv")
