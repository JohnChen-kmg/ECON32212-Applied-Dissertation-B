# This file is for 1996 Guangdong news analsis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1996 data
n96 <- read_csv("Raw Data/People's Daily News Title/PD_1996.csv")


# Extract relevant news ----
sum(str_detect(n96$news_title, "广东"))
gd <- c("广东", "粤", "广州", "深圳", "佛山", "湛江", 
        "韶关", "珠海","汕头", "佛山","江门", "茂名","肇庆", "惠州",
        "梅州", "汕尾", "河源", "阳江", "清远", "东莞", "中山", "潮州",
        "揭阳", "云浮")

n96_44 <- n96[str_detect(n96$news_title, paste(gd, collapse="|")),]
n96_44$prov_cde <- 44
dim(n96_44)

write_excel_csv(n96_44, file= "Working Data/V2.2 Individual level/News/1996/n96_44.csv")
           
