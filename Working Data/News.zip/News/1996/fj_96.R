# This file is for 1996 Fujian news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1996 data
n96 <- read_csv("Raw Data/People's Daily News Title/PD_1996.csv")


# Extract relevant news ----
sum(str_detect(n96$news_title, "福建"))

fj <- c("福建","闽", "厦门", "莆田", "三明", "泉州", 
        "漳州", "南平","龙岩", "宁德")

n96_35 <- n96[str_detect(n96$news_title, paste(fj, collapse="|")),]
n96_35$prov_cde <- 35
dim(n96_35)

write_excel_csv(n96_35, file= "Working Data/V2.2 Individual level/News/1996/n96_35.csv")
