# This file is for 1995 Hunan news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1995 data
n95 <- read_csv("Raw Data/People's Daily News Title/PD_1995.csv")


# Extract relevant news ----
sum(str_detect(n95$news_title, "湖南"))

hn <- c("湖南","湘", "长沙", "株洲", "蚌埠", "湘潭", 
        "衡阳", "邵阳","岳阳", "常德","张家界", 
        "益阳","郴州", "永州", "怀化","娄底",
        "湘西")
n95_43 <- n95[str_detect(n95$news_title, paste(hn, collapse="|")),]
n95_43$prov_cde <- 43
dim(n95_43)

write_excel_csv(n95_43, file= "Working Data/V2.2 Individual level/News/1995/n95_43.csv")
