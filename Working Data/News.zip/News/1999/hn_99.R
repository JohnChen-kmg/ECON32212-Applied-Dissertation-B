# This file is for 1999 Hunan news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1999 data
n99 <- read_csv("Raw Data/People's Daily News Title/PD_1999.csv")


# Extract relevant news ----
sum(str_detect(n99$news_title, "湖南"))

hn <- c("湖南","湘", "长沙", "株洲", "蚌埠", "湘潭", 
        "衡阳", "邵阳","岳阳", "常德","张家界", 
        "益阳","郴州", "永州", "怀化","娄底",
        "湘西")
n99_43 <- n99[str_detect(n99$news_title, paste(hn, collapse="|")),]
n99_43$prov_cde <- 43
dim(n99_43)

write_excel_csv(n99_43, file= "Working Data/V2.2 Individual level/News/1999/n99_43.csv")
