# This file is for 1998 news classification

# Prep work
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Working Data/V2.2 Individual level/News/1998")
library(haven)
library(jiebaR)
library(readxl)
library(tidyverse)
library(writexl)
library(foreign)
library(pacman)
library(tidytext)

# Load data
myFiles <- list.files(pattern="n98_.*csv")
myFiles <- myFiles[!myFiles %in% "n98_s.csv"]
n98_s <- read_csv(myFiles)
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
class_n <- read_excel("Working Data/V2.2 Individual level/News/News Classification words.xlsx")

# Classification base on frequency of the certain words
unique(class_n$type)
n98_s$economy <- 0
n98_s$legal <- 0
n98_s$politics <- 0
n98_s$rural <- 0
n98_s$technology <- 0

economy <- as.vector(class_n[class_n$type=="economy",]$word)
n98_s$economy <-ifelse(str_detect(n98_s$news_title, paste(economy, collapse="|")),1,0)

legal <- as.vector(class_n[class_n$type=="legal",]$word)
n98_s$legal <-ifelse(str_detect(n98_s$news_title, paste(legal, collapse="|")),1,0)

politics <- as.vector(class_n[class_n$type=="politics",]$word)
n98_s$politics <-ifelse(str_detect(n98_s$news_title, paste(politics, collapse="|")),1,0)

rural <- as.vector(class_n[class_n$type=="rural",]$word)
n98_s$rural <-ifelse(str_detect(n98_s$news_title, paste(rural, collapse="|")),1,0)

technology <- as.vector(class_n[class_n$type=="technology",]$word)
n98_s$technology <-ifelse(str_detect(n98_s$news_title, paste(technology, collapse="|")),1,0)

# Check
n98_s$check <- n98_s$economy + n98_s$legal + n98_s$politics + n98_s$rural + n98_s$technology
n98_s[n98_s$check>2,]


n98_s$other<-ifelse(n98_s$check==0,1,0)

n98_s %>% select(prov_cde, economy) %>% group_by(prov_cde) %>% 
        summarize(n=sum(economy)) %>% arrange(desc(n))

n98_s %>% select(prov_cde, rural) %>% group_by(prov_cde) %>% 
        summarize(n=sum(rural)) %>% arrange(desc(n))

write_excel_csv(n98_s, file= "Working Data/V2.2 Individual level/News/1998/n98_s.csv")
