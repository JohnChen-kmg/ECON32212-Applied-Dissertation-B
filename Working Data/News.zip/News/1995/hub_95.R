# This file is for 1995 Hubei news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1995 data
n95 <- read_csv("Raw Data/People's Daily News Title/PD_1995.csv")


# Extract relevant news ----
sum(str_detect(n95$news_title, "湖北"))

hub <- c("湖北", "鄂", "黄石", "十堰", "宜昌", 
        "襄阳", "鄂州","荆门", "孝感","荆州", "黄冈",
        "咸宁", "随州", "恩施", "仙桃","潜江", "天门市",
        "神农架")

n95_42 <- n95[str_detect(n95$news_title, paste(hub, collapse="|")),]
n95_42$prov_cde <- 42
dim(n95_42)

write_excel_csv(n95_42, file= "Working Data/V2.2 Individual level/News/1995/n95_42.csv")
