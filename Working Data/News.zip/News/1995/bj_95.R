# This file is for 1995 Beijing news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1995 data
n95 <- read_csv("Raw Data/People's Daily News Title/PD_1995.csv")


# Extract relevant news ----
sum(str_detect(n95$news_title, "东城"))

bj <- c("北京")

n95_11 <- n95[str_detect(n95$news_title, paste(bj, collapse="|")),]
n95_11$prov_cde <- 11
dim(n95_11)

write_excel_csv(n95_11, file= "Working Data/V2.2 Individual level/News/1995/n95_11.csv")

