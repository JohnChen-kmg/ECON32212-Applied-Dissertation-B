url <- "https://en.wikipedia.org/wiki/World_population"
ten_most_df <- read_html(url)

url <- "https://cn.govopendata.com/renminribao/2000/01/02/"
news <- read_html(url) 
n1 <- news %>%
        html_nodes("p") %>%
        html_text()
str_replace_all(n1, "[图片]", "")

mydict <- dictionary(list(all_terms = c("clouds", "storms")))
dfmat <- tokens(txt) %>%
        tokens_select(mydict) %>%
        dfm()

dfmat


tokens(paste(unlist(PD_2000[,2]), collapse =" ")) %>%
        tokens_select(c("内蒙古")) %>%
        dfm()
sum(str_count(PD_2000, "内蒙古"))
str_count(PD_2000, prov[,1])

tokens(paste(unlist(news_2000.1[,2]), collapse =" ")) %>%
        tokens_select(c("阿富汗")) %>%
        dfm()

tokens(paste(unlist(news_2000.1[,2]), collapse =" ")) %>%
        tokens_select(c("伊拉克")) %>%
        dfm()

tokens(paste(unlist(news_2001.1[,2]), collapse =" ")) %>%
        tokens_select(c("北京","河南")) %>%
        dfm()

tokens(paste(unlist(news_2001.1[,2]), collapse =" ")) %>%
        tokens_select(c("阿富汗")) %>%
        dfm()

tokens(paste(unlist(news_2001.1[,2]), collapse =" ")) %>%
        tokens_select(c("伊拉克")) %>%
        dfm()
chn_prov <- c("河北","山西","辽宁","吉林","黑龙江","江苏","浙江","安徽","福建",
              "江西","山东","河南","湖北","湖南","广东","海南","四川","贵州",
              "云南","陕西","甘肃","青海","内蒙古","广西","西藏","宁夏","新疆",
              "北京","天津","上海","重庆")
tokens(paste(unlist(PD_2000[,2]), collapse =" ")) %>%
        tokens_select(c(chn_prov)) %>%
        dfm()
