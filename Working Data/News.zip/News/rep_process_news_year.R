# This file is for replicatipn of the cleaning and classification news data for each year

setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Working Data/V2.2 Individual level/News/1995")
# Change file name
myFiles1 <- list.files(pattern = "_96.R")  
myFiles2 <- str_replace(myFiles1, "96", "95")
file.rename(myFiles1, myFiles2)

# subsitute pattern
gsub_dir( pattern = "1996", replacement = "1995")
gsub_dir( pattern = "n96", replacement = "n95")
