# This file is for 1995 Zhejiang news analsis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1995 data
n95 <- read_csv("Raw Data/People's Daily News Title/PD_1995.csv")


# Extract relevant news ----
sum(str_detect(n95$news_title, "浙江"))
zj <- c("浙江","浙", "杭州", "宁波", "温州", 
        "嘉兴", "湖州","绍兴", "金华","衢州", 
        "舟山","台州", "丽水")
n95_33 <- n95[str_detect(n95$news_title, paste(zj, collapse="|")),]
n95_33$prov_cde <- 33
dim(n95_33)

write_excel_csv(n95_33, file= "Working Data/V2.2 Individual level/News/1995/n95_33.csv")
