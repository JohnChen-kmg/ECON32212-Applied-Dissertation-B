# This file is for 1999 Beijing news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1999 data
n99 <- read_csv("Raw Data/People's Daily News Title/PD_1999.csv")


# Extract relevant news ----
sum(str_detect(n99$news_title, "东城"))

bj <- c("北京")

n99_11 <- n99[str_detect(n99$news_title, paste(bj, collapse="|")),]
n99_11$prov_cde <- 11
dim(n99_11)

write_excel_csv(n99_11, file= "Working Data/V2.2 Individual level/News/1999/n99_11.csv")

