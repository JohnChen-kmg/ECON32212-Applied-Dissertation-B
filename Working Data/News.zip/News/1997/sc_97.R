# This file is for 1997 Sichuan news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1997 data
n97 <- read_csv("Raw Data/People's Daily News Title/PD_1997.csv")


# Extract relevant news ----
sum(str_detect(n97$news_title, "四川"))
sc <- c("四川","成都", "自贡", "攀枝花", "泸州", "德阳", 
        "绵阳", "广元","遂宁", "内江","乐山", 
        "南充","眉山", "宜宾", "广安","达州", 
        "雅安","巴中", "资阳", "阿坝","甘孜", 
        "凉山")

n97_51 <- n97[str_detect(n97$news_title, paste(sc, collapse="|")),]
n97_51$prov_cde <- 51
dim(n97_51)

write_excel_csv(n97_51, file= "Working Data/V2.2 Individual level/News/1997/n97_51.csv")
