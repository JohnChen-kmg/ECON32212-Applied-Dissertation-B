# This file is for 1995 Fujian news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1995 data
n95 <- read_csv("Raw Data/People's Daily News Title/PD_1995.csv")


# Extract relevant news ----
sum(str_detect(n95$news_title, "福建"))

fj <- c("福建","闽", "厦门", "莆田", "三明", "泉州", 
        "漳州", "南平","龙岩", "宁德")

n95_35 <- n95[str_detect(n95$news_title, paste(fj, collapse="|")),]
n95_35$prov_cde <- 35
dim(n95_35)

write_excel_csv(n95_35, file= "Working Data/V2.2 Individual level/News/1995/n95_35.csv")
