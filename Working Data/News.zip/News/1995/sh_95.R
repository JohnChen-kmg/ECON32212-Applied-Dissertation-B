# This file is for 1995 Shanghai news analsis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1995 data
n95 <- read_csv("Raw Data/People's Daily News Title/PD_1995.csv")


# Extract relevant news ----
sum(str_detect(n95$news_title, "上海"))
sh <- c("上海", "沪" , "黄浦", "静安", 
        "普陀", "普陀","长宁", "卢湾","徐汇", "闸北","虹口", "杨浦",
        "宝山", "嘉定", "南汇", "奉贤", "松江", "青浦", "崇明")

n95_31 <- n95[str_detect(n95$news_title, paste(sh, collapse="|")),]
n95_31$prov_cde <- 31
dim(n95_31)

write_excel_csv(n95_31, file="Working Data/V2.2 Individual level/News/1995/n95_31.csv")
