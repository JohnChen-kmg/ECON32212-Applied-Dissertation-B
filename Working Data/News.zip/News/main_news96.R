# The output is  post classified 1996 news data for 15 provinces

# Prep work
# rm(list=ls())

# Step 1 Load the files
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Working Data/V2.2 Individual level/News/1996")
myFiles <- list.files(pattern="_96.R") 
myFiles <- myFiles[!myFiles %in% "classification_96.R"]
for(i in 1:length(myFiles)){
        setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Working Data/V2.2 Individual level/News/1996")
        source(myFiles[i])
}
rm(list=ls()) 

# Step 2 Classification
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Working Data/V2.2 Individual level/News/1996")
source("classification_96.R")
