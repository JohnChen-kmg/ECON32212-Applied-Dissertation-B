# This file is for 1997 Guangdong news analsis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1997 data
n97 <- read_csv("Raw Data/People's Daily News Title/PD_1997.csv")


# Extract relevant news ----
sum(str_detect(n97$news_title, "广东"))
gd <- c("广东", "粤", "广州", "深圳", "佛山", "湛江", 
        "韶关", "珠海","汕头", "佛山","江门", "茂名","肇庆", "惠州",
        "梅州", "汕尾", "河源", "阳江", "清远", "东莞", "中山", "潮州",
        "揭阳", "云浮")

n97_44 <- n97[str_detect(n97$news_title, paste(gd, collapse="|")),]
n97_44$prov_cde <- 44
dim(n97_44)

write_excel_csv(n97_44, file= "Working Data/V2.2 Individual level/News/1997/n97_44.csv")
           
