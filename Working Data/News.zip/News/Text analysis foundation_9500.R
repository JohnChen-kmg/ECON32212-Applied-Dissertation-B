# This file create base for news classification

# Prep work ----
library(haven)
library(jiebaR)
library(tidyverse)
library(writexl)
library(foreign)
library(pacman)
library(tidytext)
library(textrank)

# Import files
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Working Data/V2.2 Individual level/News/2000")
myFiles <- list.files(pattern="n00_s.csv")
n00_s <- read_csv(myFiles)

setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Working Data/V2.2 Individual level/News/1999")
myFiles <- list.files(pattern="n99_s.csv")
n99_s <- read_csv(myFiles)

setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Working Data/V2.2 Individual level/News/1998")
myFiles <- list.files(pattern="n98_s.csv")
n98_s <- read_csv(myFiles)

setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Working Data/V2.2 Individual level/News/1997")
myFiles <- list.files(pattern="n97_s.csv")
n97_s <- read_csv(myFiles)

setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Working Data/V2.2 Individual level/News/1996")
myFiles <- list.files(pattern="n96_s.csv")
n96_s <- read_csv(myFiles)

setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Working Data/V2.2 Individual level/News/1995")
myFiles <- list.files(pattern="n95_s.csv")
n95_s <- read_csv(myFiles)

n_s <- rbind(n00_s, n99_s, n98_s, n97_s, n96_s, n95_s)

# Keyword analysis
wk <- worker(type="tag")
# id for rows
n_s <- n_s %>% mutate(id=1:n())
# Breaking the sentence
wrds <- n_s %>%  select(news_title, id) %>% 
        mutate(words = map(n_s$news_title,tagging,jieba = wk)) %>%  
        mutate(word_tag = map(words,enframe,name = "tag",value = "word")) %>%               
        select(id,word_tag) 

# Exclude geographic names
chn_prov <- c("河北","山西","辽宁","吉林","黑龙江","江苏","浙江","安徽","福建",
              "江西","山东","河南","湖北","湖南","广东","海南","四川","贵州",
              "云南","陕西","甘肃","青海","内蒙古","广西","西藏","宁夏","新疆",
              "北京","天津","上海","重庆")

# Calculate  top 300 words in domestic news section
twrds <- wrds  %>%  unnest(cols=c("id", "word_tag")) %>% data.frame() %>% 
        select(word) %>% 
        filter(!str_detect(word, paste(chn_prov, collapse="|"))) %>%
        group_by(word)%>%summarize(n=n()) %>% arrange(desc(n)) %>% 
        slice(1:1000)

# write.cdsv
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Working Data/V2.2 Individual level/News")
write_excel_csv(twrds, file= "twrds_9500.csv")
write_excel_csv(n_s, file= "n_s9900.csv")