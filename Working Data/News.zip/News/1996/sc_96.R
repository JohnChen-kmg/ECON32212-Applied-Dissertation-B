# This file is for 1996 Sichuan news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1996 data
n96 <- read_csv("Raw Data/People's Daily News Title/PD_1996.csv")


# Extract relevant news ----
sum(str_detect(n96$news_title, "四川"))
sc <- c("四川","成都", "自贡", "攀枝花", "泸州", "德阳", 
        "绵阳", "广元","遂宁", "内江","乐山", 
        "南充","眉山", "宜宾", "广安","达州", 
        "雅安","巴中", "资阳", "阿坝","甘孜", 
        "凉山")

n96_51 <- n96[str_detect(n96$news_title, paste(sc, collapse="|")),]
n96_51$prov_cde <- 51
dim(n96_51)

write_excel_csv(n96_51, file= "Working Data/V2.2 Individual level/News/1996/n96_51.csv")
