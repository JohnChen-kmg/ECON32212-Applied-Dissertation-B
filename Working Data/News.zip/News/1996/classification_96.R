# This file is for 1996 news classification

# Prep work
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics/Working Data/V2.2 Individual level/News/1996")
library(haven)
library(jiebaR)
library(readxl)
library(tidyverse)
library(writexl)
library(foreign)
library(pacman)
library(tidytext)

# Load data
myFiles <- list.files(pattern="n96_.*csv")
myFiles <- myFiles[!myFiles %in% "n96_s.csv"]
n96_s <- read_csv(myFiles)
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
class_n <- read_excel("Working Data/V2.2 Individual level/News/News Classification words.xlsx")

# Classification base on frequency of the certain words
unique(class_n$type)
n96_s$economy <- 0
n96_s$legal <- 0
n96_s$politics <- 0
n96_s$rural <- 0
n96_s$technology <- 0

economy <- as.vector(class_n[class_n$type=="economy",]$word)
n96_s$economy <-ifelse(str_detect(n96_s$news_title, paste(economy, collapse="|")),1,0)

legal <- as.vector(class_n[class_n$type=="legal",]$word)
n96_s$legal <-ifelse(str_detect(n96_s$news_title, paste(legal, collapse="|")),1,0)

politics <- as.vector(class_n[class_n$type=="politics",]$word)
n96_s$politics <-ifelse(str_detect(n96_s$news_title, paste(politics, collapse="|")),1,0)

rural <- as.vector(class_n[class_n$type=="rural",]$word)
n96_s$rural <-ifelse(str_detect(n96_s$news_title, paste(rural, collapse="|")),1,0)

technology <- as.vector(class_n[class_n$type=="technology",]$word)
n96_s$technology <-ifelse(str_detect(n96_s$news_title, paste(technology, collapse="|")),1,0)

# Check
n96_s$check <- n96_s$economy + n96_s$legal + n96_s$politics + n96_s$rural + n96_s$technology
n96_s[n96_s$check>2,]


n96_s$other<-ifelse(n96_s$check==0,1,0)

n96_s %>% select(prov_cde, economy) %>% group_by(prov_cde) %>% 
        summarize(n=sum(economy)) %>% arrange(desc(n))

n96_s %>% select(prov_cde, rural) %>% group_by(prov_cde) %>% 
        summarize(n=sum(rural)) %>% arrange(desc(n))

write_excel_csv(n96_s, file= "Working Data/V2.2 Individual level/News/1996/n96_s.csv")
