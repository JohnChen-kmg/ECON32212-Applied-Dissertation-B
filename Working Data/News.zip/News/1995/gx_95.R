# This file is for 1995 Guangxi news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1995 data
n95 <- read_csv("Raw Data/People's Daily News Title/PD_1995.csv")


# Extract relevant news ----
sum(str_detect(n95$news_title, "广西"))

gx <- c("广西", "南宁", "柳州", "桂林", "梧州", 
        "北海", "防城港","钦州", "贵港","玉林", "百色",
        "贺州", "河池", "崇左")

n95_45 <- n95[str_detect(n95$news_title, paste(gx, collapse="|")),]
n95_45$prov_cde <- 45
dim(n95_45)

write_excel_csv(n95_45, file= "Working Data/V2.2 Individual level/News/1995/n95_45.csv")
