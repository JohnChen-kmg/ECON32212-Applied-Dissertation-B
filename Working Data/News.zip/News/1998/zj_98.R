# This file is for 1998 Zhejiang news analsis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1998 data
n98 <- read_csv("Raw Data/People's Daily News Title/PD_1998.csv")


# Extract relevant news ----
sum(str_detect(n98$news_title, "浙江"))
zj <- c("浙江","浙", "杭州", "宁波", "温州", 
        "嘉兴", "湖州","绍兴", "金华","衢州", 
        "舟山","台州", "丽水")
n98_33 <- n98[str_detect(n98$news_title, paste(zj, collapse="|")),]
n98_33$prov_cde <- 33
dim(n98_33)

write_excel_csv(n98_33, file= "Working Data/V2.2 Individual level/News/1998/n98_33.csv")
