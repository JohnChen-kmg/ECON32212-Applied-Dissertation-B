# This file is for 1996 Hebei news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1996 data
n96 <- read_csv("Raw Data/People's Daily News Title/PD_1996.csv")


# Extract relevant news ----
sum(str_detect(n96$news_title, "河北"))

hb <- c("河北", "石家庄", "唐山", "秦皇岛", "邯郸", 
        "邢台", "保定","张家口", "承德","沧州", "廊坊", "衡水")
n96_13 <- n96[str_detect(n96$news_title, paste(hb, collapse="|")),]
n96_13$prov_cde <- 13
dim(n96_13)

write_excel_csv(n96_13, file= "Working Data/V2.2 Individual level/News/1996/n96_13.csv")

