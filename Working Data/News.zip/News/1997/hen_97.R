# This file is for 1997 Henan news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1997 data
n97 <- read_csv("Raw Data/People's Daily News Title/PD_1997.csv")


# Extract relevant news ----
sum(str_detect(n97$news_title, "河南"))

hen <- c("河南", "豫", "郑州", "开封", "洛阳", 
        "平顶山", "安阳","鹤壁", "新乡","焦作", "濮阳", "许昌",
        "漯河", "三门峡","南阳", "商丘","信阳", "周口", "驻马店",
        "济源")

n97_41 <- n97[str_detect(n97$news_title, paste(hen, collapse="|")),]
n97_41$prov_cde <- 41
dim(n97_41)

write_excel_csv(n97_41, file= "Working Data/V2.2 Individual level/News/1997/n97_41.csv")
