# This file is for 1995 Anhui news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1995 data
n95 <- read_csv("Raw Data/People's Daily News Title/PD_1995.csv")


# Extract relevant news ----
sum(str_detect(n95$news_title, "安徽"))
ah <- c("安徽","皖", "合肥", "芜湖", "蚌埠", "淮南", 
        "马鞍山", "淮北","铜陵", "安庆","黄山", 
        "滁州","阜阳", "宿州", "六安","亳州", 
        "池州","宣城")

n95_34 <- n95[str_detect(n95$news_title, paste(ah, collapse="|")),]
n95_34$prov_cde <- 34
dim(n95_34)

write_excel_csv(n95_34, file= "Working Data/V2.2 Individual level/News/1995/n95_34.csv")
