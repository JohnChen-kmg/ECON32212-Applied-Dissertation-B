# This file is for 1999 Anhui news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1999 data
n99 <- read_csv("Raw Data/People's Daily News Title/PD_1999.csv")


# Extract relevant news ----
sum(str_detect(n99$news_title, "安徽"))
ah <- c("安徽","皖", "合肥", "芜湖", "蚌埠", "淮南", 
        "马鞍山", "淮北","铜陵", "安庆","黄山", 
        "滁州","阜阳", "宿州", "六安","亳州", 
        "池州","宣城")

n99_34 <- n99[str_detect(n99$news_title, paste(ah, collapse="|")),]
n99_34$prov_cde <- 34
dim(n99_34)

write_excel_csv(n99_34, file= "Working Data/V2.2 Individual level/News/1999/n99_34.csv")
