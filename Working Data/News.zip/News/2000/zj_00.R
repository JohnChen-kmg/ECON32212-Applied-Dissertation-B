# This file is for 2000 Zhejiang news analsis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 2000 data
n00 <- read_csv("Raw Data/People's Daily News Title/PD_2000.csv")


# Extract relevant news ----
sum(str_detect(n00$news_title, "浙江"))
zj <- c("浙江","浙", "杭州", "宁波", "温州", 
        "嘉兴", "湖州","绍兴", "金华","衢州", 
        "舟山","台州", "丽水")
n00_33 <- n00[str_detect(n00$news_title, paste(zj, collapse="|")),]
n00_33$prov_cde <- 33
dim(n00_33)

write_excel_csv(n00_33, file= "Working Data/V2.2 Individual level/News/2000/n00_33.csv")
