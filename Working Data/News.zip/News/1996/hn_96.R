# This file is for 1996 Hunan news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1996 data
n96 <- read_csv("Raw Data/People's Daily News Title/PD_1996.csv")


# Extract relevant news ----
sum(str_detect(n96$news_title, "湖南"))

hn <- c("湖南","湘", "长沙", "株洲", "蚌埠", "湘潭", 
        "衡阳", "邵阳","岳阳", "常德","张家界", 
        "益阳","郴州", "永州", "怀化","娄底",
        "湘西")
n96_43 <- n96[str_detect(n96$news_title, paste(hn, collapse="|")),]
n96_43$prov_cde <- 43
dim(n96_43)

write_excel_csv(n96_43, file= "Working Data/V2.2 Individual level/News/1996/n96_43.csv")
