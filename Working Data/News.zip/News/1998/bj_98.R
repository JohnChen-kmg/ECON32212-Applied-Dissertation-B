# This file is for 1998 Beijing news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1998 data
n98 <- read_csv("Raw Data/People's Daily News Title/PD_1998.csv")


# Extract relevant news ----
sum(str_detect(n98$news_title, "东城"))

bj <- c("北京")

n98_11 <- n98[str_detect(n98$news_title, paste(bj, collapse="|")),]
n98_11$prov_cde <- 11
dim(n98_11)

write_excel_csv(n98_11, file= "Working Data/V2.2 Individual level/News/1998/n98_11.csv")

