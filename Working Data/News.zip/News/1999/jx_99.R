# This file is for 1999 Jiangxi news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1999 data
n99 <- read_csv("Raw Data/People's Daily News Title/PD_1999.csv")


# Extract relevant news ----
sum(str_detect(n99$news_title, "江西"))

jx <- c("江西","赣", "南昌", "景德镇", "萍乡", "九江", 
        "新余", "鹰潭","赣州", "吉安","宜春", "上饶")

n99_36 <- n99[str_detect(n99$news_title, paste(jx, collapse="|")),]
n99_36$prov_cde <- 36
dim(n99_36)

write_excel_csv(n99_36, file= "Working Data/V2.2 Individual level/News/1999/n99_36.csv")
