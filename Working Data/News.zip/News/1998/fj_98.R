# This file is for 1998 Fujian news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1998 data
n98 <- read_csv("Raw Data/People's Daily News Title/PD_1998.csv")


# Extract relevant news ----
sum(str_detect(n98$news_title, "福建"))

fj <- c("福建","闽", "厦门", "莆田", "三明", "泉州", 
        "漳州", "南平","龙岩", "宁德")

n98_35 <- n98[str_detect(n98$news_title, paste(fj, collapse="|")),]
n98_35$prov_cde <- 35
dim(n98_35)

write_excel_csv(n98_35, file= "Working Data/V2.2 Individual level/News/1998/n98_35.csv")
