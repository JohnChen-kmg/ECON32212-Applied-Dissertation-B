# This file is for 1995 Shandong news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1995 data
n95 <- read_csv("Raw Data/People's Daily News Title/PD_1995.csv")


# Extract relevant news ----
sum(str_detect(n95$news_title, "山东"))

sd <- c("山东","济南", "青岛", "淄博", "枣庄", "东营", 
        "烟台", "潍坊","济宁", "泰安","威海", "日照",
        "临沂", "德州","聊城", "滨州","菏泽")

n95_37 <- n95[str_detect(n95$news_title, paste(sd, collapse="|")),]
n95_37$prov_cde <- 37
dim(n95_37)

write_excel_csv(n95_37, file= "Working Data/V2.2 Individual level/News/1995/n95_37.csv")
