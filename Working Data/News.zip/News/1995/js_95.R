# This file is for 1995 Jiangsu news analsis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1995 data
n95 <- read_csv("Raw Data/People's Daily News Title/PD_1995.csv")


# Extract relevant news ----
sum(str_detect(n95$news_title, "江苏"))
js <- c("江苏", "南京", "无锡", "徐州", "常州", 
        "苏州", "南通","连云港", "淮安","盐城", "扬州","镇江", "泰州",
        "宿迁")

n95_32 <- n95[str_detect(n95$news_title, paste(js, collapse="|")),]
n95_32$prov_cde <- 32
dim(n95_32)

write_excel_csv(n95_32, file= "Working Data/V2.2 Individual level/News/1995/n95_32.csv")
