# This file is for 1997 Zhejiang news analsis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1997 data
n97 <- read_csv("Raw Data/People's Daily News Title/PD_1997.csv")


# Extract relevant news ----
sum(str_detect(n97$news_title, "浙江"))
zj <- c("浙江","浙", "杭州", "宁波", "温州", 
        "嘉兴", "湖州","绍兴", "金华","衢州", 
        "舟山","台州", "丽水")
n97_33 <- n97[str_detect(n97$news_title, paste(zj, collapse="|")),]
n97_33$prov_cde <- 33
dim(n97_33)

write_excel_csv(n97_33, file= "Working Data/V2.2 Individual level/News/1997/n97_33.csv")
