# This file is for 1996 Shanghai news analsis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1996 data
n96 <- read_csv("Raw Data/People's Daily News Title/PD_1996.csv")


# Extract relevant news ----
sum(str_detect(n96$news_title, "上海"))
sh <- c("上海", "沪" , "黄浦", "静安", 
        "普陀", "普陀","长宁", "卢湾","徐汇", "闸北","虹口", "杨浦",
        "宝山", "嘉定", "南汇", "奉贤", "松江", "青浦", "崇明")

n96_31 <- n96[str_detect(n96$news_title, paste(sh, collapse="|")),]
n96_31$prov_cde <- 31
dim(n96_31)

write_excel_csv(n96_31, file="Working Data/V2.2 Individual level/News/1996/n96_31.csv")
