# This file is for 1998 Shandong news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1998 data
n98 <- read_csv("Raw Data/People's Daily News Title/PD_1998.csv")


# Extract relevant news ----
sum(str_detect(n98$news_title, "山东"))

sd <- c("山东","济南", "青岛", "淄博", "枣庄", "东营", 
        "烟台", "潍坊","济宁", "泰安","威海", "日照",
        "临沂", "德州","聊城", "滨州","菏泽")

n98_37 <- n98[str_detect(n98$news_title, paste(sd, collapse="|")),]
n98_37$prov_cde <- 37
dim(n98_37)

write_excel_csv(n98_37, file= "Working Data/V2.2 Individual level/News/1998/n98_37.csv")
