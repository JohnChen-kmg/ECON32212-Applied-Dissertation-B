# This file is for 2000 Jiangsu news analsis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 2000 data
n00 <- read_csv("Raw Data/People's Daily News Title/PD_2000.csv")


# Extract relevant news ----
sum(str_detect(n00$news_title, "江苏"))
js <- c("江苏", "南京", "无锡", "徐州", "常州", 
        "苏州", "南通","连云港", "淮安","盐城", "扬州","镇江", "泰州",
        "宿迁")

n00_32 <- n00[str_detect(n00$news_title, paste(js, collapse="|")),]
n00_32$prov_cde <- 32
dim(n00_32)

write_excel_csv(n00_32, file= "Working Data/V2.2 Individual level/News/2000/n00_32.csv")
