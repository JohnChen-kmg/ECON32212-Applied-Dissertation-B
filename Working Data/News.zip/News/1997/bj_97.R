# This file is for 1997 Beijing news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1997 data
n97 <- read_csv("Raw Data/People's Daily News Title/PD_1997.csv")


# Extract relevant news ----
sum(str_detect(n97$news_title, "东城"))

bj <- c("北京")

n97_11 <- n97[str_detect(n97$news_title, paste(bj, collapse="|")),]
n97_11$prov_cde <- 11
dim(n97_11)

write_excel_csv(n97_11, file= "Working Data/V2.2 Individual level/News/1997/n97_11.csv")

