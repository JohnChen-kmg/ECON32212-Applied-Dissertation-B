# This file is for 1998 Sichuan news analysis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1998 data
n98 <- read_csv("Raw Data/People's Daily News Title/PD_1998.csv")


# Extract relevant news ----
sum(str_detect(n98$news_title, "四川"))
sc <- c("四川","成都", "自贡", "攀枝花", "泸州", "德阳", 
        "绵阳", "广元","遂宁", "内江","乐山", 
        "南充","眉山", "宜宾", "广安","达州", 
        "雅安","巴中", "资阳", "阿坝","甘孜", 
        "凉山")

n98_51 <- n98[str_detect(n98$news_title, paste(sc, collapse="|")),]
n98_51$prov_cde <- 51
dim(n98_51)

write_excel_csv(n98_51, file= "Working Data/V2.2 Individual level/News/1998/n98_51.csv")
