# This file is for 1996 Zhejiang news analsis

# Prep work ----
setwd("/Users/jiaxiangchen/Desktop/ECON32212 Applied Dissertation B/Empirics")
# Load packages
library(readxl)
library(haven)
library(tidyverse)
library(writexl)
library(foreign)
# 1996 data
n96 <- read_csv("Raw Data/People's Daily News Title/PD_1996.csv")


# Extract relevant news ----
sum(str_detect(n96$news_title, "浙江"))
zj <- c("浙江","浙", "杭州", "宁波", "温州", 
        "嘉兴", "湖州","绍兴", "金华","衢州", 
        "舟山","台州", "丽水")
n96_33 <- n96[str_detect(n96$news_title, paste(zj, collapse="|")),]
n96_33$prov_cde <- 33
dim(n96_33)

write_excel_csv(n96_33, file= "Working Data/V2.2 Individual level/News/1996/n96_33.csv")
